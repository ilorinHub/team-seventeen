### Folder structure

# component 
--- all reusable component

# Pages
--- Whole page

# Redux

`Action` --action creators


`Reducers` -- state modifiers and initial state store
Add new files for states and reducers

`Store` --- 