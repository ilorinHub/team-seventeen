import React from 'react'

const ButtonLg = () => {
  return (
    <div></div>
  )
}

export default ButtonLg