import React from "react"
export const Loading = () => {
    return(
        <div className="">
            <p className="text-3xl font-bold underline">Loading...</p>
        </div>
    )
}