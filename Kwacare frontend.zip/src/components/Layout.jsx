import React from 'react'

const Layout = (content) => {
  return (
    <div>{content}</div>
  )
}

export default Layout