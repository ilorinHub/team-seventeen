import logo from "./logo.png"
import client from "./Client.png"
import provider from "./Provider.png"
import doctor from "./Doctor.png"
import nurse from './nurse.png'
import hospitalBed from './hospital-bed.png'
import user from './user.png'
import female from './female.png'
import male from './male.png'
import hospBed from './hosp-bed.png'
import graphReport from './graph-report.png'
import outgoing from './outgoing.png'
import laptop from './laptop.png'
import doughnut from './doughnut.png'
import facility from './facility.png'
import skyMoon from './skymoon.png'
import greenMoon from './greenmoon.png'
import deepMoon from './deepmoon.png'
import emeraldMoon from './emeraldmoon.png'


export {
    logo,
    client,
    provider,
    facility,
    doctor,
    nurse,
    hospitalBed,
    user,
    female,
    male,
    hospBed,
    graphReport,
    doughnut,
    outgoing,
    laptop,
    skyMoon,
    greenMoon,
    deepMoon,
    emeraldMoon
}