import React from 'react'
import Layout from '../../../components/DashBoard/provider/Layout'


const ProviderPrescriptions = () => {
  return ( Layout (

      <div>ProviderPrescriptions</div>
  )
  )
}

export default ProviderPrescriptions