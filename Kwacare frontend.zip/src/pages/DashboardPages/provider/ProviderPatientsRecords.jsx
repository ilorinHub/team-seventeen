import React from 'react'
import Layout from '../../../components/DashBoard/provider/Layout'


const ProviderPatientsRecords = () => {
  return ( Layout(

      <div>ProviderPatientsRecords</div>
  )
  )
}

export default ProviderPatientsRecords