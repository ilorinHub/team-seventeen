import React from 'react'
import Layout from '../../../components/DashBoard/provider/Layout'


const ProviderAppointments = () => {
  return ( Layout (
      <div>ProviderAppointments</div>
  )
  )
}

export default ProviderAppointments