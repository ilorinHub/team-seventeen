import React from 'react'
import Layout from '../../../components/DashBoard/provider/Layout'


const ProviderHospitalRecords = () => {
  return ( Layout(

      <div>ProviderHospitalRecords</div>
  )
  )
}

export default ProviderHospitalRecords