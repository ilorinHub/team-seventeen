import React from 'react'
import Layout from '../../../components/DashBoard/Facility/Layout'
const HospitalRecords = () => {
  return ( Layout(
    <div>HospitalRecords</div>
    )
  )
}

export default HospitalRecords