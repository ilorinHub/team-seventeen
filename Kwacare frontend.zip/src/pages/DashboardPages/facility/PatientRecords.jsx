import React from 'react'
import Layout from '../../../components/DashBoard/Facility/Layout'

const PatientRecords = () => {
  return ( Layout(
    <div>PatientRecords</div>
    )
  )
}

export default PatientRecords