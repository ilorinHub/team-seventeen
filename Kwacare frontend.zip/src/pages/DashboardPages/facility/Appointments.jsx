import React from 'react'
import Layout from '../../../components/DashBoard/Facility/Layout'

const Appointments = () => {
  return ( Layout(
    <div>Appointments</div>
  )
  )
}

export default Appointments