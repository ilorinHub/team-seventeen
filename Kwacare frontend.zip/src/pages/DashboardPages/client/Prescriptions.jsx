import React from 'react'
import Layout from '../../../components/DashBoard/client/Layout'


const Prescriptions = () => {
  return ( Layout (

    <div>Prescriptions</div>
  )
  )
}

export default Prescriptions