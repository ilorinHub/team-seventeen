import React from 'react'
import Layout from '../../../components/DashBoard/client/Layout'

const ClientHome = () => {
  return ( Layout(

    <div>ClientHome</div>
  )
  )
}

export default ClientHome