import React from 'react'
import Layout from '../../../components/DashBoard/client/Layout'


const MyRecords = () => {
  return ( Layout(

    <div>MyRecords</div>
  )
  )
}

export default MyRecords