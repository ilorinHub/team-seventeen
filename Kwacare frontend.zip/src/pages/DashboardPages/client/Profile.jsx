import React from 'react'
import Layout from '../../../components/DashBoard/client/Layout'

const Profile = () => {
  return ( Layout (
    
    <div>Profile</div>
  )
  )
}

export default Profile