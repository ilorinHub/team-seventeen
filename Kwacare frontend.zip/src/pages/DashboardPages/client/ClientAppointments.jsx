import React from 'react'
import Layout from '../../../components/DashBoard/client/Layout'

const ClientAppointments = () => {
  return ( Layout(
    <div>ClientAppointments</div>

  )
  )
}

export default ClientAppointments