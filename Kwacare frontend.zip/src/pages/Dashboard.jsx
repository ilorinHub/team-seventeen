// import React, {useState} from 'react'
// import { BrowserRouter, Routes, Route } from 'react-router-dom';
// import Appointments from "./DashboardPages/Appointments"
// import Overview from "./DashboardPages/Overview"
// import HospitalRecords from "./DashboardPages/HospitalRecords"
// import PatientRecords from "./DashboardPages/PatientRecords"



// const Dashboard = () => {



//   return (
//           <div>
//             <Routes >
//               {/* Dashboard */}
//               <Route exact path="/" element={<Overview />} />
//               <Route exact path='./Appointments' element={<Appointments />} />
//               {/* pages */}
//               <Route exact path='/PatientRecords' element={<PatientRecords />} />
//               <Route exact path='/HospitalRecords' element={<HospitalRecords />} />
//               <Route path='*' element='404 Not found' />
//             </Routes>
//          </div>
//   )
// }

// export default Dashboard