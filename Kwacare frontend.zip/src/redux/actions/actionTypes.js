//@define action types here and export
//@import action types to acttion creator and reducers
export const EXAMPLE = "EXAMPLE";
export const EXAMPLE_1 = "EXAMPLE_1";